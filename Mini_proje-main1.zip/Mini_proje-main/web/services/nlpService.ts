import { ApiResponse } from '../types';

const API_URL = 'http://127.0.0.1:5000/ask';

export const processQuery = async (query: string): Promise<ApiResponse> => {
  if (!query || query.trim() === '') {
    return {
      answer: "Please enter a question.",
      answer_id: "error-empty-query",
      audio_url: ""
    };
  }

  try {
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ query }),
    });

    if (!response.ok) {
      throw new Error(`API request failed with status ${response.status}`);
    }

    const data: ApiResponse = await response.json();
    return data;
  } catch (error) {
    console.error("Error communicating with the NLP backend:", error);
    // Return a structured error response
    return {
      answer: "Sorry, I couldn't connect to the NLP model. Please ensure the backend server is running and try again.",
      answer_id: "error-connect",
      audio_url: ""
    };
  }
};