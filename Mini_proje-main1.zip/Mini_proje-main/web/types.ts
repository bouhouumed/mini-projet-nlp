
export interface ChatMessage {
  id: number;
  text: string;
  sender: 'user' | 'bot';
  audioUrl?: string;
  exerciseId?: string | null;
  name?: string;
  instructions?: string[];
  target?: string[];
}

export interface Conversation {
  id: string;
  name: string;
  messages: ChatMessage[];
}

export interface DeveloperProfile {
  name: string;
  role: string;
  avatar: string;
}

export interface TeamMember {
  name: string;
  role: string;
}

export interface ApiResponse {
  answer: string;
  answer_id: string;
  audio_url: string;
}