
import { useState, useEffect, useRef, useCallback } from 'react';

interface AudioPlayerOptions {
  autoplay?: boolean;
}

export const useAudioPlayer = (src: string | null, options: AudioPlayerOptions = {}) => {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (!src) {
        setIsPlaying(false);
        setProgress(0);
        return;
    }

    audioRef.current = new Audio(src);
    const audio = audioRef.current;

    const handleTimeUpdate = () => {
      if (audio.duration > 0) {
        setProgress((audio.currentTime / audio.duration) * 100);
      }
    };
    const handleEnded = () => {
      setIsPlaying(false);
      setProgress(100); 
    };
    const handlePlay = () => setIsPlaying(true);
    const handlePause = () => setIsPlaying(false);

    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('ended', handleEnded);
    audio.addEventListener('play', handlePlay);
    audio.addEventListener('pause', handlePause);
    
    if (options.autoplay) {
        audio.play().catch(e => console.error("Autoplay failed:", e));
    }

    return () => {
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('ended', handleEnded);
      audio.removeEventListener('play', handlePlay);
      audio.removeEventListener('pause', handlePause);
      audio.pause();
      audioRef.current = null;
    };
  }, [src, options.autoplay]);

  const play = useCallback(() => {
    if (audioRef.current) {
        audioRef.current.play().catch(e => console.error("Playback failed:", e));
    }
  }, []);

  const pause = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause();
    }
  }, []);

  return { isPlaying, progress, play, pause };
};
