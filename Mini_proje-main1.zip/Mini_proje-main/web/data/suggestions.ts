export const conversationStarters: string[] = [
  "Can you recommend effective core ab exercises?",
  "How can I incorporate physical activity into my day if I have a busy schedule?",
  "Why is physical activity important?",
  "How can I manage stress and maintain a healthy work-life balance?",
  "I have a busy travel schedule. How can I maintain my fitness routine?",
  "How can I optimize my nutrition to support my fitness goals?"
];

export const exerciseSuggestions: string[] = [
  "band shrug",
  "barbell decline close grip to skull press",
  "push-up inside leg kick",
  "cable incline fly (on stability ball)",
  "kettlebell double alternating hang clean"
];

// Function to get a random subset of exercise suggestions
export const getRandomExerciseSuggestions = (count: number = 4): string[] => {
  const shuffled = [...exerciseSuggestions].sort(() => 0.5 - Math.random());
  return shuffled.slice(0, count);
};
