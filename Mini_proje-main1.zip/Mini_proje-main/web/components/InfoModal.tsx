import React, { useState, useEffect } from 'react';
import type { TeamMember } from '../types';

// Framer Motion will be available globally from the CDN script
const motion = (window as any).framerMotion;
const AnimatePresence = motion ? motion.AnimatePresence : React.Fragment;

interface InfoModalProps {
    isOpen: boolean;
    onClose: () => void;
}

export const InfoModal: React.FC<InfoModalProps> = ({ isOpen, onClose }) => {
    const [teamData, setTeamData] = useState<TeamMember[]>([]);

    useEffect(() => {
        if (isOpen) {
            fetch('./data/team.json')
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => setTeamData(data))
                .catch(error => {
                    console.error("Failed to fetch team data:", error);
                    setTeamData([]);
                });
        }
    }, [isOpen]);

    const MotionComponent = motion ? motion.div : 'div';
    const motionProps = {
        initial: { opacity: 0, scale: 0.95, y: 20 },
        animate: { opacity: 1, scale: 1, y: 0 },
        exit: { opacity: 0, scale: 0.95, y: 20 },
        transition: { duration: 0.2, ease: 'easeInOut' }
    };

    return (
        <AnimatePresence>
            {isOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                    {/* Backdrop */}
                    <MotionComponent
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        onClick={onClose}
                        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
                    />

                    {/* Modal */}
                    <MotionComponent
                        {...(motion ? motionProps : {})}
                        className="relative z-10 w-full max-w-2xl bg-gray-800 border border-gray-700 rounded-xl shadow-lg max-h-[90vh] flex flex-col"
                    >
                        {/* Header */}
                        <div className="flex-shrink-0 p-4 flex justify-between items-center border-b border-gray-700">
                            <div className="w-8" /> {/* Spacer to balance the close button */}
                            <h1 className="text-2xl font-title text-transparent bg-clip-text bg-gradient-to-r from-[#3D91A8] to-cyan-400 text-center">
                                GYM BOT
                            </h1>
                            <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors w-8">
                                <i className="fas fa-times text-xl"></i>
                            </button>
                        </div>
                        
                        <div className="flex-1 overflow-y-auto p-6">
                            {/* Team Section */}
                            <div>
                                <h2 className="font-semibold text-lg text-[#3D91A8] mb-4 border-l-4 border-[#3D91A8] pl-3">Meet The Team</h2>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    {teamData.map((member, index) => (
                                        <div key={index} className="group bg-gray-700/50 p-4 rounded-lg border border-gray-600 transition-all duration-300 hover:border-[#3D91A8] hover:scale-[1.02]">
                                            <div className="flex items-center gap-4">
                                                <div className="bg-gray-600 p-2 rounded-full">
                                                    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-gray-400 group-hover:text-[#3D91A8] transition-colors">
                                                        <circle cx="12" cy="6" r="4" stroke="currentColor" strokeWidth="1.5"></circle>
                                                        <path d="M19.9975 18C20 17.8358 20 17.669 20 17.5C20 15.0147 16.4183 13 12 13C7.58172 13 4 15.0147 4 17.5C4 19.9853 4 22 12 22C14.231 22 15.8398 21.8433 17 21.5634" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"></path>
                                                    </svg>
                                                </div>
                                                <div>
                                                    <h3 className="font-bold text-white">{member.name}</h3>
                                                    <p className="text-sm text-gray-400 mt-1">{member.role}</p>
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>

                        {/* Footer */}
                        <div className="flex-shrink-0 p-4 border-t border-gray-700">
                            <a 
                                href="https://github.com/ilyasshassouni45-code/Mini_proje" 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="flex items-center justify-center gap-2 w-full bg-gray-700 hover:bg-gray-600 text-gray-300 font-semibold py-2 px-4 rounded-lg transition-colors"
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 496 512" className="w-5 h-5" fill="currentColor">
                                    <path d="M165.9 397.4c0 2-2.3 3.6-5.2 3.6-3.3 .3-5.6-1.3-5.6-3.6 0-2 2.3-3.6 5.2-3.6 3-.3 5.6 1.3 5.6 3.6zm-31.1-4.5c-.7 2 1.3 4.3 4.3 4.9 2.6 1 5.6 0 6.2-2s-1.3-4.3-4.3-5.2c-2.6-.7-5.5 .3-6.2 2.3zm44.2-1.7c-2.9 .7-4.9 2.6-4.6 4.9 .3 2 2.9 3.3 5.9 2.6 2.9-.7 4.9-2.6 4.6-4.6-.3-1.9-3-3.2-5.9-2.9zM244.8 8C106.1 8 0 113.3 0 252c0 110.9 69.8 205.8 169.5 239.2 12.8 2.3 17.3-5.6 17.3-12.1 0-6.2-.3-40.4-.3-61.4 0 0-70 15-84.7-29.8 0 0-11.4-29.1-27.8-36.6 0 0-22.9-15.7 1.6-15.4 0 0 24.9 2 38.6 42.1 20.9 35.7 54.9 25.4 68.3 19.4 2.1-15.1 8.6-25.4 15.9-31.2-56.4-6.4-115.2-28-115.2-124.3 0-27.5 7.6-50 21.6-67.6-2.6-6.4-11.1-33.3 2.6-67.6 20.9-6.5 69 27.2 69 27.2 20-5.6 41.5-8.5 62.8-8.5s42.8 2.9 62.8 8.5c0 0 48.1-33.6 69-27.2 13.7 34.3 5.2 61.2 2.6 67.6 14 17.6 21.6 40.1 21.6 67.6 0 96.6-58.8 117.9-115.4 124.2 9.2 7.9 17.2 23.5 17.2 47.4 0 34.3-.3 75.2-.3 85.5 0 6.6 4.6 14.8 17.5 12.1C428.2 457.8 496 362.9 496 252 496 113.3 383.5 8 244.8 8zM97.2 352.9c-1.3 1-1 3.3 .7 5.2 1.6 1.6 3.9 2.3 5.2 1 1.3-1 1-3.3-.7-5.2-1.6-1.6-3.9-2.3-5.2-1zm-10.8-8.1c-.7 1.3 .3 2.9 2.3 3.9 1.6 1 3.6 .7 4.3-.7 .7-1.3-.3-2.9-2.3-3.9-2-.6-3.6-.3-4.3 .7zm32.4 35.6c-1.6 1.3-1 4.3 1.3 6.2 2.3 2.3 5.2 2.6 6.5 1 1.3-1.3 .7-4.3-1.6-6.2-2.2-2.3-5.2-2.6-6.2-1zm-11.4-14.7c-1.6 1-1.6 3.6 0 5.9 1.6 2.3 4.3 3.3 5.6 2.3 1.6-1.3 1.6-3.9 0-6.2-1.4-2.3-4-3.3-5.6-2z"/>
                                </svg>
                                <span>View Technical Info on GitHub</span>
                            </a>
                        </div>
                    </MotionComponent>
                </div>
            )}
        </AnimatePresence>
    );
};
