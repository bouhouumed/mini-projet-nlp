import React from 'react';

// Framer Motion will be available globally from the CDN script
const motion = (window as any).framerMotion;
const AnimatePresence = motion ? motion.AnimatePresence : React.Fragment;

interface ConfirmationModalProps {
    isOpen: boolean;
    onClose: () => void;
    onConfirm: () => void;
    title: string;
    message: string;
}

export const ConfirmationModal: React.FC<ConfirmationModalProps> = ({ isOpen, onClose, onConfirm, title, message }) => {
    // Use a standard div if framer-motion is not available
    const MotionComponent = motion ? motion.div : 'div';
    const motionProps = {
        initial: { opacity: 0, scale: 0.95 },
        animate: { opacity: 1, scale: 1 },
        exit: { opacity: 0, scale: 0.95 },
        transition: { duration: 0.2, ease: 'easeInOut' }
    };

    return (
        <AnimatePresence>
            {isOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                    {/* Backdrop */}
                    <MotionComponent
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        onClick={onClose}
                        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
                    />

                    {/* Modal */}
                    <MotionComponent
                        {...(motion ? motionProps : {})}
                        className="relative z-10 w-full max-w-sm p-6 bg-gray-800 border border-gray-700 rounded-xl shadow-lg"
                    >
                        <h3 className="text-lg font-bold text-white">{title}</h3>
                        <p className="mt-2 text-sm text-gray-400">{message}</p>
                        
                        <div className="mt-6 flex justify-end gap-3">
                            <button
                                onClick={onClose}
                                className="px-4 py-2 text-sm font-medium text-gray-300 bg-gray-700 rounded-md hover:bg-gray-600 focus:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-opacity-75 transition-colors"
                            >
                                Cancel
                            </button>
                            <button
                                onClick={onConfirm}
                                className="px-4 py-2 text-sm font-medium text-white bg-red-600 rounded-md hover:bg-red-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-red-500 focus-visible:ring-offset-2 focus-visible:ring-offset-gray-800 transition-colors"
                            >
                                Delete
                            </button>
                        </div>
                    </MotionComponent>
                </div>
            )}
        </AnimatePresence>
    );
};
