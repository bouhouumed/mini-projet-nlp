import React, { useState } from 'react';
import type { Conversation } from '../types';
import { ConfirmationModal } from './ConfirmationModal';

interface ChatSidebarProps {
    conversations: Conversation[];
    activeConversationId: string | null;
    onSelectConversation: (id: string) => void;
    onNewConversation: () => void;
    onDeleteConversation: (id: string) => void;
}

export const ChatSidebar: React.FC<ChatSidebarProps> = (props) => {
    const [deleteTarget, setDeleteTarget] = useState<Conversation | null>(null);

    const handleDeleteClick = (e: React.MouseEvent, convo: Conversation) => {
        e.stopPropagation();
        setDeleteTarget(convo);
    };

    const confirmDelete = () => {
        if (deleteTarget) {
            props.onDeleteConversation(deleteTarget.id);
            setDeleteTarget(null);
        }
    };

    const cancelDelete = () => {
        setDeleteTarget(null);
    };

    return (
        <>
            <div className="bg-gray-800/50 h-full flex flex-col overflow-hidden border-r border-gray-700">
                <div className="p-3 flex-shrink-0">
                    <button 
                        onClick={props.onNewConversation}
                        title="New Chat"
                        className="w-full bg-[#3D91A8] hover:bg-cyan-500 text-white font-bold py-3 rounded-lg transition-colors flex items-center justify-center"
                    >
                        <i className="fas fa-plus text-xl"></i>
                    </button>
                </div>
                <div className="flex-1 overflow-y-auto p-2 space-y-1 scrollbar-hide min-h-0">
                    {props.conversations.map(convo => (
                        <div
                            key={convo.id}
                            onClick={() => props.onSelectConversation(convo.id)}
                            className={`group flex justify-between items-center w-full text-left p-2 rounded-md cursor-pointer transition-colors ${
                                props.activeConversationId === convo.id 
                                ? 'bg-[#3D91A8]/30 text-white' 
                                : 'text-gray-300 hover:bg-gray-700/50'
                            }`}
                        >
                            <span className="truncate flex-1 text-sm">{convo.name.replace('Chat ', 'C')}</span>
                            <button 
                                onClick={(e) => handleDeleteClick(e, convo)}
                                className="text-gray-500 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity ml-2"
                                aria-label={`Delete ${convo.name}`}
                            >
                                <i className="fas fa-trash-alt"></i>
                            </button>
                        </div>
                    ))}
                </div>
            </div>

            <ConfirmationModal
                isOpen={!!deleteTarget}
                onClose={cancelDelete}
                onConfirm={confirmDelete}
                title="Delete Conversation"
                message={`Are you sure you want to permanently delete "${deleteTarget?.name}"? This action cannot be undone.`}
            />
        </>
    );
};