import React, { useState } from 'react';
import { ChatView } from './ChatView';
import { ChatSidebar } from './ChatSidebar';
import type { Conversation } from '../types';

interface ChatContainerProps {
    toggleChat: () => void;
    conversations: Conversation[];
    activeConversationId: string | null;
    onSelectConversation: (id: string) => void;
    onNewConversation: () => void;
    onDeleteConversation: (id: string) => void;
    onSendMessage: (text: string, conversationId: string | null) => void;
    isLoading: boolean;
}

export const ChatContainer: React.FC<ChatContainerProps> = (props) => {
    const [isSidebarOpen, setIsSidebarOpen] = useState(false);
    
    const activeConversation = props.conversations.find(c => c.id === props.activeConversationId) || null;

    return (
        <div className="p-0.5 bg-gray-700 rounded-2xl shadow-2xl shadow-black/30 h-full">
            <div className="flex flex-col h-full bg-gray-900/90 backdrop-blur-lg rounded-[15px] overflow-hidden">
                <header className="p-4 flex justify-between items-center flex-shrink-0">
                    <button 
                        onClick={() => setIsSidebarOpen(!isSidebarOpen)} 
                        className="text-gray-400 hover:text-white transition-colors"
                        aria-label={isSidebarOpen ? 'Close sidebar' : 'Open sidebar'}
                    >
                        <i className={`fas ${isSidebarOpen ? 'fa-times' : 'fa-bars'} text-xl`}></i>
                    </button>
                    <h2 className="font-bold text-white truncate px-4">{activeConversation?.name || 'GYM BOT'}</h2>
                    <button onClick={props.toggleChat} className="text-gray-400 hover:text-white transition-colors">
                        <i className="fas fa-chevron-down text-xl"></i>
                    </button>
                </header>

                <div className={`flex-1 overflow-hidden chat-container-grid min-h-0 ${isSidebarOpen ? 'sidebar-open' : ''}`}>
                    <ChatSidebar 
                        conversations={props.conversations}
                        activeConversationId={props.activeConversationId}
                        onSelectConversation={props.onSelectConversation}
                        onNewConversation={props.onNewConversation}
                        onDeleteConversation={props.onDeleteConversation}
                    />
                    <ChatView 
                        activeConversation={activeConversation}
                        onSendMessage={(text) => props.onSendMessage(text, props.activeConversationId)}
                        isLoading={props.isLoading}
                    />
                </div>
            </div>
        </div>
    );
};