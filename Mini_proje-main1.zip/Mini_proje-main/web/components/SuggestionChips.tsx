import React from 'react';

// Framer Motion will be available globally from the CDN script
const motion = (window as any).framerMotion;

interface SuggestionChipsProps {
    suggestions: string[];
    onSuggestionClick: (suggestion: string) => void;
}

export const SuggestionChips: React.FC<SuggestionChipsProps> = ({ suggestions, onSuggestionClick }) => {
    if (!suggestions || suggestions.length === 0) {
        return null;
    }

    const MotionComponent = motion ? motion.div : 'div';
    const motionProps = {
        initial: { opacity: 0, y: 10 },
        animate: { opacity: 1, y: 0 },
        transition: { duration: 0.3, delay: 0.2 }
    };

    return (
        <MotionComponent {...(motion ? motionProps : {})} className="px-4 pb-2">
            <div className="flex items-center gap-2 overflow-x-auto scrollbar-hide">
                {suggestions.map((suggestion, index) => (
                    <button
                        key={index}
                        onClick={() => onSuggestionClick(suggestion)}
                        className="flex-shrink-0 px-3 py-1.5 text-sm text-gray-300 bg-gray-700/50 border border-gray-600 rounded-full hover:bg-[#3D91A8] hover:border-[#3D91A8] hover:text-white transition-colors whitespace-nowrap"
                    >
                        {suggestion}
                    </button>
                ))}
            </div>
        </MotionComponent>
    );
};
