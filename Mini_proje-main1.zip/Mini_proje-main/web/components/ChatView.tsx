import React, { useState, useEffect, useRef, useCallback } from 'react';
import type { Conversation } from '../types';
import { useSpeechRecognition } from '../hooks/useSpeechRecognition';
import { ChatMessageDisplay } from './ChatMessageDisplay';
import { SuggestionChips } from './SuggestionChips';
import { conversationStarters, getRandomExerciseSuggestions } from '../data/suggestions';

interface ChatViewProps {
    activeConversation: Conversation | null;
    onSendMessage: (text: string) => void;
    isLoading: boolean;
}

export const ChatView: React.FC<ChatViewProps> = ({ activeConversation, onSendMessage, isLoading }) => {
    const [inputValue, setInputValue] = useState('');
    const messagesEndRef = useRef<HTMLDivElement>(null);
    const textAreaRef = useRef<HTMLTextAreaElement>(null);

    const handleSendMessage = useCallback(() => {
        if (inputValue.trim() === '' || isLoading) return;
        onSendMessage(inputValue);
        setInputValue('');
    }, [inputValue, isLoading, onSendMessage]);

    const handleSuggestionClick = (suggestion: string) => {
        onSendMessage(suggestion);
        setInputValue('');
    };

    const onSpeechResult = useCallback((transcript: string) => {
        setInputValue(transcript);
    }, []);

    const { isListening, toggleListening, error, hasRecognitionSupport } = useSpeechRecognition(onSpeechResult);
    
    useEffect(() => {
        if (error) {
            alert(error);
        }
    }, [error]);

    const handleMicClick = () => {
        document.querySelectorAll('audio').forEach(audio => audio.pause());
        toggleListening();
    };

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    useEffect(scrollToBottom, [activeConversation?.messages]);

    useEffect(() => {
        if (textAreaRef.current) {
            textAreaRef.current.style.height = 'auto';
            textAreaRef.current.style.height = `${textAreaRef.current.scrollHeight}px`;
        }
    }, [inputValue]);
    
    // Auto-focus input when switching conversations
    useEffect(() => {
        setTimeout(() => textAreaRef.current?.focus(), 100);
    }, [activeConversation?.id]);


    const handleKeyPress = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSendMessage();
        }
    };

    const getSuggestions = () => {
        if (!activeConversation || isLoading) return [];
        
        const messages = activeConversation.messages;
        const lastMessage = messages[messages.length - 1];
        
        // Show conversation starters for a new chat
        if (messages.length === 1 && lastMessage.sender === 'bot') {
            return conversationStarters;
        }

        // Show exercise suggestions after a bot response
        if (lastMessage.sender === 'bot') {
            return getRandomExerciseSuggestions();
        }

        return [];
    };

    const suggestions = getSuggestions();

    return (
        <div className="flex flex-col h-full bg-gray-900/50 overflow-hidden">
            <div className="flex-1 p-4 overflow-y-auto scrollbar-hide min-h-0">
                <div className="space-y-4">
                    {activeConversation ? (
                        activeConversation.messages.map((message, index) => (
                            <ChatMessageDisplay 
                                key={message.id} 
                                message={message} 
                                isLastBotMessage={index === activeConversation.messages.length - 1 && message.sender === 'bot'}
                            />
                        ))
                    ) : (
                        <div className="text-center text-gray-500 pt-10">Select or create a conversation to start.</div>
                    )}
                    {isLoading && (
                        <div className="flex items-end gap-3 justify-start">
                            <svg viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg" className="w-8 h-8 text-[#3D91A8] self-start flex-shrink-0">
                                <path fill="currentColor" d="M17.7530511,13.999921 C18.9956918,13.999921 20.0030511,15.0072804 20.0030511,16.249921 L20.0030511,17.1550008 C20.0030511,18.2486786 19.5255957,19.2878579 18.6957793,20.0002733 C17.1303315,21.344244 14.8899962,22.0010712 12,22.0010712 C9.11050247,22.0010712 6.87168436,21.3444691 5.30881727,20.0007885 C4.48019625,19.2883988 4.00354153,18.2500002 4.00354153,17.1572408 L4.00354153,16.249921 C4.00354153,15.0072804 5.01090084,13.999921 6.25354153,13.999921 L17.7530511,13.999921 Z M11.8985607,2.00734093 L12.0003312,2.00049432 C12.380027,2.00049432 12.6938222,2.2826482 12.7434846,2.64872376 L12.7503312,2.75049432 L12.7495415,3.49949432 L16.25,3.5 C17.4926407,3.5 18.5,4.50735931 18.5,5.75 L18.5,10.254591 C18.5,11.4972317 17.4926407,12.504591 16.25,12.504591 L7.75,12.504591 C6.50735931,12.504591 5.5,11.4972317 5.5,10.254591 L5.5,5.75 C5.5,4.50735931 6.50735931,3.5 7.75,3.5 L11.2495415,3.49949432 L11.2503312,2.75049432 C11.2503312,2.37079855 11.5324851,2.05700336 11.8985607,2.00734093 L12.0003312,2.00049432 L11.8985607,2.00734093 Z M9.74928905,6.5 C9.05932576,6.5 8.5,7.05932576 8.5,7.74928905 C8.5,8.43925235 9.05932576,8.99857811 9.74928905,8.99857811 C10.4392523,8.99857811 10.9985781,8.43925235 10.9985781,7.74928905 C10.9985781,7.05932576 10.4392523,6.5 9.74928905,6.5 Z M14.2420255,6.5 C13.5520622,6.5 12.9927364,7.05932576 12.9927364,7.74928905 C12.9927364,8.43925235 13.5520622,8.99857811 14.2420255,8.99857811 C14.9319888,8.99857811 15.4913145,8.43925235 15.4913145,7.74928905 C15.4913145,7.05932576 14.9319888,6.5 14.2420255,6.5 Z" />
                            </svg>
                            <div className="max-w-md lg:max-w-lg px-4 py-3 rounded-2xl shadow-md bg-gray-700 text-gray-200 rounded-bl-none">
                                <span className="animate-pulse">Bot is typing...</span>
                            </div>
                        </div>
                    )}
                    <div ref={messagesEndRef} />
                </div>
            </div>
            {suggestions.length > 0 && !isLoading && (
                <SuggestionChips suggestions={suggestions} onSuggestionClick={handleSuggestionClick} />
            )}
            <div className="p-4 bg-gray-800/50 border-t border-gray-700 flex items-end gap-2">
                {hasRecognitionSupport && (
                    <button
                        onClick={handleMicClick}
                        className={`w-10 h-10 flex-shrink-0 flex items-center justify-center rounded-full transition-colors ${
                            isListening ? 'bg-red-500 text-white animate-pulse' : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                        }`}
                        aria-label={isListening ? 'Stop listening' : 'Start listening'}
                    >
                        <i className="fas fa-microphone text-lg"></i>
                    </button>
                )}
                <textarea
                    ref={textAreaRef}
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Ask about exercises..."
                    className="flex-1 bg-gray-700 text-gray-200 rounded-lg px-4 py-2 resize-none max-h-32 focus:outline-none focus:ring-2 focus:ring-[#3D91A8] scrollbar-hide"
                    rows={1}
                />
                <button
                    onClick={handleSendMessage}
                    disabled={isLoading || !inputValue.trim()}
                    className="w-10 h-10 flex-shrink-0 bg-[#3D91A8] text-white rounded-full flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed hover:bg-cyan-500 transition-colors"
                    aria-label="Send message"
                >
                    <i className="fas fa-paper-plane"></i>
                </button>
            </div>
        </div>
    );
};
