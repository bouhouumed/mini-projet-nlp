import React from 'react';
import type { ChatMessage } from '../types';
import { useAudioPlayer } from '../hooks/useAudioPlayer';

// Framer Motion will be available globally from the CDN script
const motion = (window as any).framerMotion;

interface ChatMessageDisplayProps {
    message: ChatMessage;
    isLastBotMessage: boolean;
}

const BotIcon = () => (
    <svg viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg" className="w-8 h-8 text-[#3D91A8] self-start mt-1 flex-shrink-0">
        <path fill="currentColor" d="M17.7530511,13.999921 C18.9956918,13.999921 20.0030511,15.0072804 20.0030511,16.249921 L20.0030511,17.1550008 C20.0030511,18.2486786 19.5255957,19.2878579 18.6957793,20.0002733 C17.1303315,21.344244 14.8899962,22.0010712 12,22.0010712 C9.11050247,22.0010712 6.87168436,21.3444691 5.30881727,20.0007885 C4.48019625,19.2883988 4.00354153,18.2500002 4.00354153,17.1572408 L4.00354153,16.249921 C4.00354153,15.0072804 5.01090084,13.999921 6.25354153,13.999921 L17.7530511,13.999921 Z M11.8985607,2.00734093 L12.0003312,2.00049432 C12.380027,2.00049432 12.6938222,2.2826482 12.7434846,2.64872376 L12.7503312,2.75049432 L12.7495415,3.49949432 L16.25,3.5 C17.4926407,3.5 18.5,4.50735931 18.5,5.75 L18.5,10.254591 C18.5,11.4972317 17.4926407,12.504591 16.25,12.504591 L7.75,12.504591 C6.50735931,12.504591 5.5,11.4972317 5.5,10.254591 L5.5,5.75 C5.5,4.50735931 6.50735931,3.5 7.75,3.5 L11.2495415,3.49949432 L11.2503312,2.75049432 C11.2503312,2.37079855 11.5324851,2.05700336 11.8985607,2.00734093 L12.0003312,2.00049432 L11.8985607,2.00734093 Z M9.74928905,6.5 C9.05932576,6.5 8.5,7.05932576 8.5,7.74928905 C8.5,8.43925235 9.05932576,8.99857811 9.74928905,8.99857811 C10.4392523,8.99857811 10.9985781,8.43925235 10.9985781,7.74928905 C10.9985781,7.05932576 10.4392523,6.5 9.74928905,6.5 Z M14.2420255,6.5 C13.5520622,6.5 12.9927364,7.05932576 12.9927364,7.74928905 C12.9927364,8.43925235 13.5520622,8.99857811 14.2420255,8.99857811 C14.9319888,8.99857811 15.4913145,8.43925235 15.4913145,7.74928905 C15.4913145,7.05932576 14.9319888,6.5 14.2420255,6.5 Z" fillRule="nonzero"></path>
    </svg>
);

const UserIcon = () => (
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-8 h-8 text-gray-400 self-start mt-1 flex-shrink-0">
        <circle cx="12" cy="6" r="4" stroke="currentColor" strokeWidth="1.5"></circle>
        <path d="M19.9975 18C20 17.8358 20 17.669 20 17.5C20 15.0147 16.4183 13 12 13C7.58172 13 4 15.0147 4 17.5C4 19.9853 4 22 12 22C14.231 22 15.8398 21.8433 17 21.5634" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"></path>
    </svg>
);

export const ChatMessageDisplay: React.FC<ChatMessageDisplayProps> = ({ message }) => {
    const { play, pause, isPlaying, progress } = useAudioPlayer(message.audioUrl || null, { autoplay: false });
    
    const isExercise = message.name && message.instructions && message.exerciseId;
    const isUser = message.sender === 'user';

    const motionProps = {
        initial: { opacity: 0, y: 10 },
        animate: { opacity: 1, y: 0 },
        transition: { duration: 0.3 }
    };

    // Use a standard div if framer-motion is not available
    const MotionComponent = motion ? motion.div : 'div';

    return (
        <MotionComponent {...(motion ? motionProps : {})} className={`flex items-end gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}>
            {!isUser && <BotIcon />}
            
            <div className={`max-w-md lg:max-w-lg px-4 py-3 rounded-2xl shadow-md break-words ${
                isUser
                ? 'bg-gradient-to-br from-[#3D91A8] to-cyan-600 text-white rounded-br-none'
                : 'bg-gray-700 text-gray-200 rounded-bl-none'
            }`}>
                {isExercise ? (
                    <div className="space-y-3">
                        <h4 className="font-bold text-[#3D91A8] text-lg capitalize">{message.name}</h4>
                        {message.exerciseId && (
                            <div className="w-full bg-gray-800 rounded-lg overflow-hidden my-2 border border-gray-600">
                                <img src={`https://static.exercisedb.dev/media/${message.exerciseId}.gif`} alt={message.name || ''} className="w-full h-auto object-cover"/>
                            </div>
                        )}
                        <div>
                            <h5 className="font-semibold text-white mb-1">Instructions:</h5>
                            <ol className="list-decimal list-inside text-gray-300 space-y-1 text-sm pl-2">
                                {message.instructions?.map((step, index) => <li key={index}>{step}</li>)}
                            </ol>
                        </div>
                    </div>
                ) : (
                    <p>{message.text}</p>
                )}

                {message.audioUrl && (
                     <div className="mt-3 pt-2 border-t border-gray-600/50 flex items-center gap-3">
                        <button onClick={isPlaying ? pause : play} className="text-[#3D91A8] hover:text-cyan-400 text-2xl">
                            <i className={`fas ${isPlaying ? 'fa-pause-circle' : 'fa-play-circle'}`}></i>
                        </button>
                        <div className="w-full bg-gray-600 rounded-full h-1.5">
                            <div className="bg-[#3D91A8] h-1.5 rounded-full" style={{ width: `${progress}%` }}></div>
                        </div>
                    </div>
                )}
            </div>

            {isUser && <UserIcon />}
        </MotionComponent>
    );
};