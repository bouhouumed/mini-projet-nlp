import React, { useState, useEffect } from 'react';
import ChatWidget from './components/ChatWidget';
import type { Conversation, ChatMessage } from './types';
import { processQuery } from './services/nlpService';
import { InfoModal } from './components/InfoModal';

const parseBotResponse = (response: any): Partial<ChatMessage> => {
  const { answer, audio_url } = response;
  const parsedData: Partial<ChatMessage> = {
    text: answer,
    audioUrl: audio_url ? `http://127.0.0.1:5000${audio_url}` : undefined,
  };

  const exerciseIdMatch = answer.match(/Exercise ID:\s*(\w+)/);
  if (exerciseIdMatch) parsedData.exerciseId = exerciseIdMatch[1];

  const nameMatch = answer.match(/Name:\s*(.+)/);
  if (nameMatch) parsedData.name = nameMatch[1];
  
  const instructionsMatch = answer.match(/Instructions:\s*(\[.*\])/);
  if (instructionsMatch) {
      try {
          const instructionsRaw = instructionsMatch[1].replace(/'/g, '"');
          const instructionsArray = JSON.parse(instructionsRaw);
          parsedData.instructions = instructionsArray.map((inst: string) => inst.replace(/^Step:\d+\s*/, ''));
      } catch (e) { console.error("Could not parse instructions", e); }
  }
  return parsedData;
};


const App: React.FC = () => {
  // Lazily initialize state from localStorage to prevent race conditions on load
  const [conversations, setConversations] = useState<Conversation[]>(() => {
    try {
      const savedConversations = localStorage.getItem('gymBotConversations');
      if (savedConversations && savedConversations !== '[]') {
        return JSON.parse(savedConversations);
      }
    } catch (error) {
      console.error("Failed to load or parse conversations from localStorage during init", error);
    }
    return []; // Default to an empty array if nothing is saved or an error occurs
  });

  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isInfoModalOpen, setIsInfoModalOpen] = useState(false);

  // Effect to handle initial setup: creating a new chat if none exist,
  // or setting the active chat from the loaded ones.
  useEffect(() => {
    if (conversations.length === 0) {
      // If no conversations were loaded, create a new default one.
      const newConversation: Conversation = {
        id: `chat-${Date.now()}`,
        name: 'Chat 1',
        messages: [{ id: 1, text: "Hello! I'm your virtual gym coach. How can I help you?", sender: 'bot' }],
      };
      setConversations([newConversation]);
      setActiveConversationId(newConversation.id);
    } else if (!activeConversationId) {
      // If conversations were loaded but no active one is set, default to the first.
      setActiveConversationId(conversations[0].id);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // This effect should only run once on mount.

  // Save conversations to localStorage whenever they change
  useEffect(() => {
    try {
        if (conversations.length > 0) {
            localStorage.setItem('gymBotConversations', JSON.stringify(conversations));
        } else {
            // This ensures that if all chats are deleted, the storage is cleared
            localStorage.removeItem('gymBotConversations');
        }
    } catch (error) {
        console.error("Failed to save conversations to localStorage", error);
    }
  }, [conversations]);

  const handleNewConversation = (openChat = true) => {
    const chatNumbers = conversations
      .map(c => {
        const match = c.name.match(/^Chat (\d+)$/);
        return match ? parseInt(match[1], 10) : 0;
      })
      .filter(num => num > 0);

    const maxNumber = chatNumbers.length > 0 ? Math.max(...chatNumbers) : 0;
    const newChatNumber = maxNumber + 1;

    const newConversation: Conversation = {
      id: `chat-${Date.now()}`,
      name: `Chat ${newChatNumber}`,
      messages: [{ id: 1, text: "Hello! I'm your virtual gym coach. How can I help you?", sender: 'bot' }],
    };
    setConversations(prev => [...prev, newConversation]);
    setActiveConversationId(newConversation.id);
    if (openChat) {
      setIsChatOpen(true);
    }
  };

  const handleDeleteConversation = (id: string) => {
    setConversations(prev => prev.filter(c => c.id !== id));
    // If the deleted conversation was the active one, switch to another or clear
    if (activeConversationId === id) {
      const remainingConvos = conversations.filter(c => c.id !== id);
      setActiveConversationId(remainingConvos.length > 0 ? remainingConvos[0].id : null);
    }
  };

  const handleSendMessage = async (text: string, conversationId: string | null) => {
    if (!text.trim() || !conversationId || isLoading) return;
    
    const userMessage: ChatMessage = { id: Date.now(), text, sender: 'user' };
    
    // Update state immediately with user message
    setConversations(prev =>
      prev.map(c => c.id === conversationId ? { ...c, messages: [...c.messages, userMessage] } : c)
    );
    setIsLoading(true);

    try {
        const botResponseData = await processQuery(text);
        const parsedData = parseBotResponse(botResponseData);
        const botMessage: ChatMessage = { 
            id: Date.now() + 1, 
            sender: 'bot',
            text: botResponseData.answer,
            ...parsedData
        };

        // Update state with bot response
        setConversations(prev =>
            prev.map(c => c.id === conversationId ? { ...c, messages: [...c.messages, botMessage] } : c)
        );
    } catch (error) {
        console.error("Error processing query in App.tsx:", error);
        const errorMessage: ChatMessage = { id: Date.now() + 1, text: "Sorry, an error occurred.", sender: 'bot' };
        setConversations(prev =>
            prev.map(c => c.id === conversationId ? { ...c, messages: [...c.messages, errorMessage] } : c)
        );
    } finally {
        setIsLoading(false);
    }
  };


  return (
    <div className="font-sans h-screen flex flex-col" style={{ fontFamily: "'Inter', sans-serif" }}>
      <main className="flex-grow flex flex-col items-center justify-center text-center p-4">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" className="w-48 h-48 md:w-64 md:h-64 mb-6 text-[#3D91A8] animated-logo">
            <path d="M6 12.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 0 1h-3a.5.5 0 0 1-.5-.5M3 8.062C3 6.76 4.235 5.765 5.53 5.886a26.6 26.6 0 0 0 4.94 0C11.765 5.765 13 6.76 13 8.062v1.157a.93.93 0 0 1-.765.935c-.845.147-2.34.346-4.235.346s-3.39-.2-4.235-.346A.93.93 0 0 1 3 9.219zm4.542-.827a.25.25 0 0 0-.217.068l-.92.9a25 25 0 0 1-1.871-.183.25.25 0 0 0-.068.495c.55.076 1.232.149 2.02.193a.25.25 0 0 0 .189-.071l.754-.736.847 1.71a.25.25 0 0 0 .404.062l.932-.97a25 25 0 0 0 1.922-.188.25.25 0 0 0-.068-.495c-.538.074-1.207.145-1.98.189a.25.25 0 0 0-.166.076l-.754.785-.842-1.7a.25.25 0 0 0-.182-.135"/>
            <path d="M8.5 1.866a1 1 0 1 0-1 0V3h-2A4.5 4.5 0 0 0 1 7.5V8a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1v1a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-1a1 1 0 0 0 1-1V9a1 1 0 0 0-1-1v-.5A4.5 4.5 0 0 0 10.5 3h-2zM14 7.5V13a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V7.5A3.5 3.5 0 0 1 5.5 4h5A3.5 3.5 0 0 1 14 7.5"/>
        </svg>

        <h1 className="text-5xl md:text-6xl font-title text-transparent bg-clip-text bg-gradient-to-r from-[#3D91A8] to-cyan-400 mb-2">
          GYM BOT
        </h1>
        <button 
          onClick={() => setIsInfoModalOpen(true)}
          className="mt-4 px-6 py-2 bg-white/10 border border-white/20 rounded-full text-gray-300 hover:bg-white/20 transition-colors backdrop-blur-md"
        >
          Team Info
        </button>
      </main>

      <footer className="w-full text-center p-4 text-sm text-gray-500">
        GYM BOT © 2025. All Rights Reserved
      </footer>

      <ChatWidget
        isOpen={isChatOpen}
        toggleChat={() => setIsChatOpen(!isChatOpen)}
        conversations={conversations}
        activeConversationId={activeConversationId}
        onSelectConversation={(id) => setActiveConversationId(id)}
        onNewConversation={handleNewConversation}
        onDeleteConversation={handleDeleteConversation}
        onSendMessage={handleSendMessage}
        isLoading={isLoading}
      />

      <InfoModal 
        isOpen={isInfoModalOpen} 
        onClose={() => setIsInfoModalOpen(false)}
      />
    </div>
  );
};

export default App;