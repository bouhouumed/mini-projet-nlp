
# NLP Chatbot 

## Step 1: Install Required Libraries

To install the necessary libraries for the NLP chatbot, run the following command:

1. **Install Python Dependencies:**

   ```bash
   pip install -r requirements.txt
   ```

2. **Start the Flask Server:**

   ```bash
   python app.py
   ```

   This will run the Flask server for the chatbot API.

## Step 2: Install Node.js

Download and install Node.js from the official website:

* [Download Node.js](https://nodejs.org/en/download)
* **Direct Link (for Windows)**: [Node.js v24.11.1](https://nodejs.org/dist/v24.11.1/node-v24.11.1-x64.msi)

## Step 3: Set Up the Frontend

1. **Navigate to the Web Directory:**

   ```bash
   cd web
   ```

2. **Install Node.js Dependencies:**

   ```bash
   npm install
   ```

3. **Run the Frontend Development Server:**

   ```bash
   npm run dev
   ```

This will start the frontend server.

## Step 4: Access the Web App

Once both servers are running (Flask API and frontend), you can access the web application at:

[http://127.0.0.1:3000](http://127.0.0.1:3000)
