import os
import re
import time
import pickle
import pandas as pd
import numpy as np
from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from gtts import gTTS
from sklearn.metrics.pairwise import cosine_similarity
from nltk.stem import PorterStemmer
from nltk.corpus import stopwords

# -------------------------
# 1. Initial Setup
# -------------------------
app = Flask(__name__) # لا تنسَ التعديل الذي قمنا به سابقاً
CORS(app)

# تهيئة أدوات معالجة النص (ما زلنا نحتاجها للاستعلامات الجديدة)
stemmer = PorterStemmer()
stop_words = set(stopwords.words("english"))

# -------------------------
# 2. Load Pre-trained Models
# -------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
models_dir = os.path.join(BASE_DIR, "models")

# تحميل الـ Vectorizer
with open(os.path.join(models_dir, "vectorizer.pkl"), "rb") as f:
    vectorizer = pickle.load(f)

# تحميل قاعدة البيانات المعالجة
df = pd.read_pickle(os.path.join(models_dir, "knowledge_base.pkl"))

# إعادة حساب مصفوفة TF-IDF من البيانات المحملة (خطوة سريعة)
matrix = vectorizer.transform(df["clean"])
print("✅ Models loaded successfully. The app is ready.")

# -------------------------
# 3. Text Cleaning Function (for new queries)
# -------------------------
def clean_text(text):
    text = str(text).lower()
    text = re.sub(r"[^a-zA-Z0-9 ]", " ", text)
    words = text.split()
    words = [stemmer.stem(w) for w in words if w not in stop_words]
    return " ".join(words)

# -------------------------
# 4. Routes
# -------------------------
@app.route("/", methods=["GET"])
def home():
    return render_template("index.html")

@app.route("/ask", methods=["POST"])
def ask():
    data = request.get_json()
    query = data.get("query", "")

    if not query.strip():
        return jsonify({"answer": "Please enter a question."})

    cleaned_query = clean_text(query)
    query_vec = vectorizer.transform([cleaned_query])
    sims = cosine_similarity(query_vec, matrix)[0]
    idx = np.argmax(sims)

    if sims[idx] < 0.15:
        response_text = "Sorry, I don't understand your question. 🤔"
        answer_id = "unknown"
    else:
        response_text = df.iloc[idx]["Answer"] + " 💪"
        answer_id = idx # نستخدم index الصف كـ ID فريد للإجابة

    # --- AUDIO GENERATION ---
    audio_folder = os.path.join(BASE_DIR, "static", "audio")
    os.makedirs(audio_folder, exist_ok=True)
    
    timestamp = int(time.time())
    file_name = f"{timestamp}.mp3"
    audio_path = os.path.join(audio_folder, file_name)
    
    tts = gTTS(response_text, lang="en")
    tts.save(audio_path)
    
    audio_url = f"/static/audio/{file_name}"

    # إرجاع JSON يحتوي على كل المعلومات
    return jsonify({
        "answer": response_text,
        "audio_url": audio_url,
        "answer_id": str(answer_id) # تحويله إلى نص لضمان التوافق
    })

# -------------------------
# 5. Run App
# -------------------------
if __name__ == "__main__":
    app.run(debug=True)