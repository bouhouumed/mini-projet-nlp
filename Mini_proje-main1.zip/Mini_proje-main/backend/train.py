import os
import re
import pandas as pd
import nltk
import pickle

from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from sklearn.feature_extraction.text import TfidfVectorizer

print("Starting the training process...")

# -------------------------
# 1. NLTK Setup
# -------------------------
try:
    stopwords.words("english")
except LookupError:
    nltk.download("stopwords")

stop_words = set(stopwords.words("english"))
stemmer = PorterStemmer()

# -------------------------
# 2. Text Cleaning Function
# -------------------------
def clean_text(text):
    text = str(text).lower()
    text = re.sub(r"[^a-zA-Z0-9 ]", " ", text)
    words = text.split()
    words = [stemmer.stem(w) for w in words if w not in stop_words]
    return " ".join(words)

# -------------------------
# 3. Load and Process Data
# -------------------------
# تحديد المسارات بناءً على موقع ملف train.py
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_DIR = os.path.dirname(BASE_DIR)
DATA_DIR = os.path.join(PROJECT_DIR, "data")

print("Loading data files...")
d1 = pd.read_csv(os.path.join(DATA_DIR, "coach_data1.csv"))
d2 = pd.read_csv(os.path.join(DATA_DIR, "coach_data2.csv"))

kb = []

for _, row in d1.iterrows():
    question = f"{row['name']} {row['targetMuscles']} {row['instructions']}"
    answer = (
        f"Exercise ID: {row['exerciseId']}\n"
        f"Name: {row['name']}\n"
        f"Target: {row['targetMuscles']}\n"
        f"Instructions: {row['instructions']}"
    )
    kb.append((question, answer))

for _, row in d2.iterrows():
    kb.append((row["Question"], row["Answer"]))

df = pd.DataFrame(kb, columns=["Question", "Answer"])
print(f"Knowledge base created with {len(df)} entries.")

print("Cleaning and processing text...")
df["clean"] = df["Question"].apply(clean_text)

# -------------------------
# 4. TF-IDF Vectorization
# -------------------------
print("Creating TF-IDF vectorizer and matrix...")
vectorizer = TfidfVectorizer()
matrix = vectorizer.fit_transform(df["clean"])
# ملاحظة: نحن لا نحتاج لحفظ الـ matrix نفسها، فقط الـ vectorizer و الـ df

# -------------------------
# 5. Save the trained models/objects
# -------------------------
# سننشئ مجلد جديد لحفظ النماذج
models_dir = os.path.join(BASE_DIR, "models")
os.makedirs(models_dir, exist_ok=True)

# حفظ الـ Vectorizer
with open(os.path.join(models_dir, "vectorizer.pkl"), "wb") as f:
    pickle.dump(vectorizer, f)

# حفظ قاعدة البيانات المعالجة (DataFrame)
df.to_pickle(os.path.join(models_dir, "knowledge_base.pkl"))

print("--------------------------------------------------")
print("✅ Training complete!")
print(f"Models saved in '{models_dir}' directory.")
print("You can now run app.py")
print("--------------------------------------------------")